<!DOCTYPE html>
<html>
<head>
    <title>Journal</title>
</head>
<body>
    <h1>Welcome to Online Journal</h1>
    <p><a href="view/login.php"> Login</a></p>
    <p><a href="view/sign-up.php">Sign Up</a></p>
</body>
</html>