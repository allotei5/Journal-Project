<?php

//call on the user class
require('../classes/userclass.php');

//controller function to add user
function addusercontroller($user_id, $user_password){
    $insertuser = new user_class;
    
    //run the insert method
    $runinsert = $insertuser->adduser_method($user_id, $user_password);
    
    if ($runinsert){
        return $runinsert;
    }else{
        return false;
    }
}

?>