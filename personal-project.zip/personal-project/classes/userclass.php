<?php

//include the database class
require('../settings/db-class.php');

class user_class extends db_connection{
    //properties
    public $user_id = null;
    public $user_name = null;
    public $user_password = null;
    
    //method for inserting new user
    public function adduser_method($user_name, $u_pass){
        //write the query
        $sql = "INSERT INTO `user`(`username`,`password`) VALUES('$user_name', '$u_pass')";
        
        //run the query
        return $this->db_query($sql);
    }
}

?>