<?php
//Database credentials
define("DATABASE", "journal");
define("SERVER", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");

?>